<div id="home-slider">
	<div class="container">
		<ul class="sliders owl-carousel">
			<li><a href="#"><img src="data/slides/1.jpg" alt="slides"></a></li>
			<li><a href="#"><img src="data/slides/2.jpg" alt="slides"></a></li>
			<li><a href="#"><img src="data/slides/3.jpg" alt="slides"></a></li>
			<li><a href="#"><img src="data/slides/4.jpg" alt="slides"></a></li>
		</ul>
	</div>
</div>
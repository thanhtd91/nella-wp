<?php
define('MAIN_URL','http://localhost/html/nella/');

$data_owl= array(
	'items'=>3,
	'margin'=>0,
	'loop'=>'false',
	'center'=>"false",
	'mouseDrag'=>"true",
	'touchDrag'=>"true",
	'pullDrag'=>"true",
	'freeDrag'=>'false',
	'stagePadding'=>0,
	'merge'=>'false',
	'mergeFit'=>'true',
	'autoWidth'=>'true',
	'startPosition'=>0,
	'URLhashListener'=>'flase',
	'nav'=>'true',
	'navRewind'=>'true',
	// 'navText'=> array(
	// 	'<i class="fa fa-angle-left"></i>',
	// 	'<i class="fa fa-angle-right"></i>'
	// ),
	'autoplay'=>'false',
	'autoplayHoverPause'=>'false',
	'smartSpeed'=>'500',
	// 'responsive'=>array(
	// 	array(
	// 		"0"=>1,
	// 		"600"=>2,
	// 		"1000"=>4
	// 	)
	// ),
	'animateOut'=>'',
	'animateIn'=>''
);
// echo "<pre>";print_r($data_owl);

// echo json_encode($data_owl);
// echo "</pre>";
?>
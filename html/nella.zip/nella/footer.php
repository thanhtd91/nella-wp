		<footer id="footer">
			<!-- Band -->
			<div class="bands-slider">
				<div class="brands-slider-wrapper">
					<div class="container">
						<div class="brand-paralax">
							<ul class="list-bands owl-carousel" data-items="4" data-nav="true">
								<li>
									<a href="#">
										<img src="data/bands/1-manusize.jpg" alt="bands logo">
									</a>
								</li>
								<li>
									<a href="#">
										<img src="data/bands/2-manusize.jpg" alt="bands logo">
									</a>
								</li>
								<li>
									<a href="#">
										<img src="data/bands/3-manusize.jpg" alt="bands logo">
									</a>
								</li>
								<li>
									<a href="#">
										<img src="data/bands/4-manusize.jpg" alt="bands logo">
									</a>
								</li>
								<li>
									<a href="#">
										<img src="data/bands/5-manusize.jpg" alt="bands logo">
									</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				
			</div>
			<!-- Band -->
			<div class="footer">
				
			</div>
		</footer>
		</div>
	</div>
	<!-- Script-->
	<script type="text/javascript" src="assets/lib/jquery/jquery-1.11.2.min.js"></script>
	<script type="text/javascript" src="assets/lib/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/lib/owl.carousel/owl.carousel.min.js"></script>
	<script type="text/javascript" src="assets/lib/jquery-ui/jquery-ui.min.js"></script>
	<script type="text/javascript" src="assets/lib/jquery.countdown/jquery.countdown.min.js"></script>
	<script type="text/javascript" src="assets/js/style.js"></script>
</body>
</html>